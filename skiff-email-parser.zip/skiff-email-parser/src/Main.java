import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        ArrayList<String> names = new ArrayList<>();
        File emails = new File("emails.txt");
        try {
            Scanner info = new Scanner(emails);
            while(info.hasNextLine()) {
                String line = info.nextLine();
                if (line.contains("From: ")) {
                    names.add(line);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("This file does not exist");
        }

        for (int i = 0; i < names.size(); i++) {
            trim(names.get(i), names);
        }


        ArrayList<String> singleTime = new ArrayList<>();

        for (int i = 0; i < names.size(); i++) {
                String theName = names.get(i);
                if (!singleTime.contains(theName)) {
                    singleTime.add(theName);
                }
        }

        Collections.sort(singleTime);
        System.out.println("All the names once:");
        for (int i = 0; i < singleTime.size(); i++) {
            System.out.println(singleTime.get(i));
        }

        File nameFile = new File("names.txt");
        try {
            FileWriter writer = new FileWriter(nameFile);
            writer.flush();

            for (int i = 0; i < singleTime.size(); i++) {
                writer.append(singleTime.get(i)+ "\n");
            }
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("This file does not exist");
        }
    }

    public static void trim(String trimString, ArrayList<String> arrayList) {
        int space = 0;
        for (int i = 0; i < trimString.length(); i++) {
            if (trimString.charAt(i) == ' ') {
                space = i +1;
            }
        }
        int trimStringLength = trimString.length();
        trimString = trimString.substring(space, trimStringLength);

        String compareName = " ";
        for (int i = 0; i < arrayList.size(); i++) {
            compareName = arrayList.get(i);
            if (compareName.contains(trimString)) {
                arrayList.set(i, trimString);
            }
        }

    }
}
